import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Created by sc on 6/2/2017.
 */
public class AndroidGmailApp {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("device", "Android");

        //capabilities that are mandatory
        capabilities.setCapability("deviceName", "Android");
        capabilities.setCapability("platformName", "Android");
        //capabilities.setCapability("udid","TA93309ITV");
        capabilities.setCapability("udid", "emulator-5554");
        //capabilities.setCapability("browserName", "Chrome");
        capabilities.setCapability("appPackage", "com.android.email");
        capabilities.setCapability("appActivity", ".activity.Welcome");


        WebDriver dr = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        dr.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

        dr.findElement(By.id("com.android.email:id/compose_button")).click();
        dr.findElement(By.id("com.android.email:id/to")).sendKeys("sonichalasani@yahoo.com.com");
        String text1 = "sonichalasani";
        dr.findElement(By.id("com.android.email:id/subject")).sendKeys("Hi");

        dr.findElement(By.id("com.android.email:id/body")).sendKeys("How are you?hehe");

        dr.findElement(By.id("com.android.email:id/send")).click();

        dr.findElement(By.xpath("//android.widget.ImageButton[@index=0]")).click();
        //Press on sent folder
        dr.findElement(By.xpath("//android.widget.LinearLayout[@index=8]")).click();
        dr.findElement(By.xpath("//android.view.View[@index=0]")).click();

        //Get the info from the sent email--Get text from sent email address
        //Compare this with the sent address-- You put while sending the email
        String text2 = dr.findElement(By.xpath("//android.widget.TextView[@text='to sonichalasani']")).getText();

        if(text2.contains(text1)) {
            System.out.println("The Message is sent successfully");
        }
        dr.quit();
    }

}
