package samplecode;

/**
 * Created by sc on 4/7/2017.
 */
public class TraditionalHouse extends House {

    TraditionalHouse(){
        System.out.println("Init Traditional House");
    }

    public void construction(){
        System.out.println("Constructing  Traditional House");

    }

    // ***********************Static method*******************************
    public static void Login(){
        System.out.println("Logging into the application");
    }
}
