package samplecode;

/**
 * Created by sc on 4/7/2017.
 */
public class House {

    public String house_color = "Green";
    House(){
        System.out.println("Initializing");
    }

    public void construction(){
        System.out.println("Constructing House");

    }
}
