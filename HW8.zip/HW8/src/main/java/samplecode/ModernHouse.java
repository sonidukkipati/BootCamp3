package samplecode;

/**
 * Created by sc on 4/7/2017.
 */
public class ModernHouse extends House {

   // private String house_color = "Brown";


    ModernHouse(){
        System.out.println("Init Modern House");
    }

    public void construction(){
        System.out.println("Constructing  Modern House");

    }
}
