package samplecode;

/**
 * Created by sc on 4/7/2017.
 */
public class ConservativeHouse extends House {


    ConservativeHouse(){
        System.out.println("Init Conservative House");
    }

    public void construction(){
        System.out.println("Constructing  Conservative House");

    }


}
